﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiVeterinaria.Models.Reservacion
{
    public class csReservacionEstructura
    {
        public class requestReservacion
        {
            public int id_reserva { get; set; }
            public string fecha { get; set; }
            public int dpi { get; set; }
            public int id_mascota { get; set; }
            public string estado { get; set; }
            public string hora { get; set; }

            public class responseReservacion
        {
                public int respuesta { get; set; }
                public string descripcion_respuesta {get; set; }
        }
            public class requestEliminarReservacion
        {
            public int id_reserva { get; set;}
        }
                   
        }
    }
}
