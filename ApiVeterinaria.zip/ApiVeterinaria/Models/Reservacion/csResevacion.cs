﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using static ApiVeterinaria.Models.Reservacion.csReservacionEstructura.requestReservacion;

namespace ApiVeterinaria.Models.Reservacion
{
    public class csReservacion
    {
        public responseReservacion InsertarReservacion(int id_reserva, string fecha,
        int dpi, int id_mascota, string estado, string hora)
        {
            responseReservacion result = new responseReservacion();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "insert into reservacion (id_reserva, fecha, dpi, id_mascota, estado, hora) values " +
                    "(" + id_reserva + " , '" + fecha + "', '" + dpi + "', " + id_mascota + ", '"+estado+"', '" + hora + "' )";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Reservacion insertada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al insertar Reservacion: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }

        public responseReservacion ActualizarReservacion(int id_reserva, string fecha,
            int dpi, int id_mascota, string estado, string hora)
        {
            responseReservacion result = new responseReservacion();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "update reservacion set fecha ='" + fecha + "',dpi = " + dpi+ ", estado ='" + estado + "', hora = '" + hora + "',id_mascota = " + id_mascota + "  where id_reserva = " + id_reserva + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Reservacion actualizada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al actualizar Reservacion: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public responseReservacion EliminarReservacion(int id_reserva)
        {
            responseReservacion result = new responseReservacion();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "delete from reservacion where id_reserva = " + id_reserva + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Reservacion eliminada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al eliminar Reservacion: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public DataSet ListarReservacion()

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from reservacion ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Reservacion";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }
        }
        public DataSet ListarReservacionxid(int id_reserva)

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from resevacion where id_reserva = " + id_reserva + "";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Reservacion";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }

        }
    }
}