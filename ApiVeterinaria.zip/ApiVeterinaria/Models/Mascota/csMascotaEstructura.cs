﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiVeterinaria.Models.Mascota
{
    public class csMascotaEstructura
    {
        public class requestMascota
        {
        public int id_mascota { get; set; }
        public string nombre_m { get; set; }
        public string raza { get; set; }
        public string fecha_nacimiento { get; set; }
        public string sexo { get; set; }
        public string color { get; set; }
        public string especie { get; set; }
        public int dpi { get; set; }
            public class responseMascota
        {
            public int respuesta { get; set; }
            public string descripcion_respuesta { get; set; }
        }
            public class requestEliminarMascota
        {
                public int id_mascota { get; set; }
        }
        }
    }
}