﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using static ApiVeterinaria.Models.Mascota.csMascotaEstructura.requestMascota;

namespace ApiVeterinaria.Models.Mascota
{
    public class csMascota
    {
        public responseMascota InsertarMascota(int id_mascota, string nombre_m,
        string raza, string fecha_nacimiento, string sexo, string color, string especie, int dpi)
        {
            responseMascota result = new responseMascota();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "insert into mascota (id_mascota, nombre_m, raza, fecha_nacimiento, sexo, color, especie, dpi) values " +
                    "(" + id_mascota + " , '" + nombre_m + "', '" + raza + "', '" + fecha_nacimiento + "', '"+sexo+"', '"+color+"', '"+especie+"', "+dpi+" )";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Mascota insertada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al insertar Mascota: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }

        public responseMascota ActualizarMascota(int id_mascota, string nombre_m,
        string raza, string fecha_nacimiento, string sexo, string color, string especie, int dpi)
        {
            responseMascota result = new responseMascota();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "update mascota set nombre_m ='" + nombre_m + "', raza ='" + raza + "', fecha_nacimiento ='" + fecha_nacimiento + "', sexo = '" + sexo + "', color = '" + color + "', especie ='" + especie + "' where id_mascota = " + id_mascota + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Mascota actualizada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al actualizar Mascota: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public responseMascota EliminarMascota(int id_mascota)
        {
            responseMascota result = new responseMascota();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "delete from mascota where id_mascota = " + id_mascota + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Mascota eliminada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al eliminar Mascota: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public DataSet ListarMascota()

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from mascota ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Mascotas";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }
        }
        public DataSet ListarMascotaxid(int id_mascota)

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from mascota where id_mascota = " + id_mascota + "";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Mascota";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }
        }
    }
}

