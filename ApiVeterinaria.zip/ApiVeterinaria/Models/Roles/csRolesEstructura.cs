﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiVeterinaria.Models.Roles
{
    public class csRolesEstructura
    {
        public class requestRoles
        {
        public int id_rol { get; set; }
        public string nombre_rol { get; set; }

            public class responseRoles
        {
            public int respuesta { get; set; }
            public string descripcion_respuesta { get; set; }
        }
            public class requestEliminarRoles
        {
                public int id_rol { get; set; }
        }
        }

    }
}