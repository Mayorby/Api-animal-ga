﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using static ApiVeterinaria.Models.Roles.csRolesEstructura.requestRoles;

namespace ApiVeterinaria.Models.Roles
{
    public class csRoles
    {
        public responseRoles InsertarRoles(int id_rol, string nombre_rol)
        {
            responseRoles result = new responseRoles();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "insert into roles (id_rol, nombre_rol) values " +
                    "(" + id_rol + " , '" + nombre_rol + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Rol insertado correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al insertar Rol: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }

        public responseRoles ActualizarRoles(int id_rol, string nombre_rol)
        {
            responseRoles result = new responseRoles();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "update roles set nombre_rol ='" + nombre_rol + "' where id_producto = " + id_rol + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Rol actualizado correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al actualizar Rol: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public responseRoles EliminarRoles(int id_rol)
        {
            responseRoles result = new responseRoles();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "delete from roles where id_rol = " + id_rol + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Rol eliminado correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al eliminar Rol: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public DataSet ListarRoles()

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from roles";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Roles";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }
        }
        public DataSet ListarRolesxid(int id_rol)

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from roles where id_rol = " + id_rol + "";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Roles";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }
        }
    }
}