﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using static ApiVeterinaria.Models.Producto.csProductoEstructura.requestProducto;

namespace ApiVeterinaria.Models.Producto
{
    public class csProducto
    {
        public responseProducto InsertarProducto(int id_producto, string nombre_p,
        string descripcion, int precio, string imagen)
        {
            responseProducto result = new responseProducto();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "insert into producto (id_producto, nombre_p, descripcion, precio, imagen) values " +
                    "(" + id_producto + " , '" + nombre_p + "', '" + descripcion + "', " + precio + ", '"+imagen+"')";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Producto insertado correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al insertar Producto: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }

        public responseProducto ActualizarProducto(int id_producto, string nombre_p,
string descripcion, int precio, string imagen)
        {
            responseProducto result = new responseProducto();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "update producto set nombre_p ='" + nombre_p + "',descripcion ='" + descripcion + "', precio =" + precio + ", imagen ='" + imagen + "' where id_producto = " + id_producto + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Producto actualizado correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al actualizar Producto: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public responseProducto EliminarProducto(int id_producto)
        {
            responseProducto result = new responseProducto();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "delete from producto where id_producto = " + id_producto + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Producto eliminado correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al eliminar Producto: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public DataSet ListarProducto()

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from producto ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Productos";
                return dsi;
            }
            catch (Exception)
            {

            return null;

            }
        }
        public DataSet ListarProductoxid(int id_producto)

            {
                DataSet dsi = new DataSet();
                string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                SqlConnection con = new SqlConnection(conexion);
                con.Open();

                try
                {
                    string query = "select * from producto where id_producto = " + id_producto + "";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dsi);
                    dsi.Tables[0].TableName = "Lista Productos";
                    return dsi;
                }
                catch (Exception)
                {

                    return null;

                }
            }
    }
}