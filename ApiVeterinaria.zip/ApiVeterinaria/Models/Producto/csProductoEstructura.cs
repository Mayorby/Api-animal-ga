﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace ApiVeterinaria.Models.Producto
{
    public class csProductoEstructura
    {
        public class requestProducto
        {
        public int id_producto { get; set; }
        public string nombre_p { get; set; }
        public string descripcion { get; set; }
        public int precio { get; set; }
        public string imagen { get; set; }

            public class responseProducto
        {
            public int respuesta { get; set; }
            public string descripcion_respuesta { get; set; }
        }
        public class requestEliminarProducto
        {
             public int id_producto { get; set; }
        }
        }
    }
}