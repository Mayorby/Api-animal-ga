﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using static ApiVeterinaria.Models.Usuario.csUsuarioEstructura.requestUsuario;
using System.Web.Management;
using System.Security.Cryptography;


namespace ApiVeterinaria.Models.Usuario
{
    public class csUsuario
    {
        public responseUsuario ValidaUsuario(int dpi, string contraseña)
        {
            responseUsuario result = new responseUsuario();
            string conexion = "";
            DataSet dsi = new DataSet();
            SqlConnection con = new SqlConnection();
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = " Select * from usuario where dpi =" + dpi + " and  contraseña = '" + contraseña + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "login";
                result.respuesta = dsi.Tables[0].Rows.Count;
                result.descripcion_respuesta ="";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error Validar: " + ex.Message.ToString();
            }
            con.Close();
            return result;

        }



        public responseUsuario InsertarUsuario(int dpi, string nombre,
               string correo_electronico, string fecha_nacimiento, string telefono, string direccion, string contraseña, int id_rol)
        {
            responseUsuario result = new responseUsuario();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "insert into usuario (dpi, nombre, correo_electronico, fecha_nacimiento, telefono, direccion, contraseña, id_rol ) values " +
                    "(" + dpi + " , '" + nombre + "', '" + correo_electronico + "', '" + fecha_nacimiento + "', '"+telefono+"', '" + direccion + "', '" + contraseña + "', " + id_rol + " )";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Usuario insertada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al insertar Usuario: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }

        public responseUsuario ActualizarUsuario(int dpi, string nombre,
            string correo_electronico, string fecha_nacimiento, string telefono, string direccion, string contraseña, int id_rol)
        {
            responseUsuario result = new responseUsuario();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "update usuario set nombre ='" + nombre + "',correo_electronico = " + correo_electronico+ ", fecha_nacimiento ='" + fecha_nacimiento + "', telefono = '" + telefono + "',direccion = '" + direccion + "', id_rol "+ id_rol +"  where dpi = " + dpi + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Usuario actualizada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al actualizar Usuario: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public responseUsuario EliminarUsuario(int dpi)
        {
            responseUsuario result = new responseUsuario();
            string conexion = "";
            SqlConnection con = null;
            try
            {
                conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
                con = new SqlConnection(conexion);
                con.Open();
                string query = "delete from usuario where dpi = " + dpi + "";
                SqlCommand cmd = new SqlCommand(query, con);
                result.respuesta = cmd.ExecuteNonQuery();
                result.descripcion_respuesta = "Usuario eliminada correctamente";
            }
            catch (Exception ex)
            {
                result.respuesta = 0;
                result.descripcion_respuesta = "Error al eliminar Usuario: " + ex.Message.ToString();
            }
            con.Close();
            return result;
        }
        public DataSet ListarUsuario()

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from usuario ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Usuario";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }
        }
        public DataSet ListarUsuarioxid(int dpi)

        {
            DataSet dsi = new DataSet();
            string conexion = ConfigurationManager.ConnectionStrings["cnConexion"].ConnectionString;
            SqlConnection con = new SqlConnection(conexion);
            con.Open();

            try
            {
                string query = "select * from usuario where dpi = " + dpi + "";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsi);
                dsi.Tables[0].TableName = "Lista Usuario";
                return dsi;
            }
            catch (Exception)
            {

                return null;

            }

        }
    }
}