﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiVeterinaria.Models.Usuario
{
    public class csUsuarioEstructura
    {
        public class requestUsuario
        {
            public int dpi { get; set; }
            public string nombre { get; set; }
            public string correo_electronico { get; set; }
            public string fecha_nacimiento { get; set; }
            public string telefono { get; set; }
            public string direccion { get; set; }
            public string contraseña { get; set; }
            public int id_rol { get; set; }

            public class responseUsuario
            {
                public int respuesta { get; set; }
                public string descripcion_respuesta { get; set; }
            }
            public class requestEliminarUsuario
            {
                public int dpi { get; set; }
            }

        }
    }
}