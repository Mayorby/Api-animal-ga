﻿namespace ApiVeterinaria.Controllers
{
    public class requestLogin
    {
    }
}