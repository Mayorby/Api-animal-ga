﻿using ApiVeterinaria.Models.Usuario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using static ApiVeterinaria.Models.Usuario.csUsuarioEstructura;

namespace ApiVeterinaria.Controllers
{
    public class UsuarioController : ApiController
    {
        [HttpPost]
        [Route("api/rest/validaUsuario")]
        public IHttpActionResult ValidaUsuario(requestUsuario model)
        {
            return Ok(new csUsuario().ValidaUsuario(model.dpi, model.contraseña));
        }

        [HttpPost]
        [Route("api/rest/insertaUsuario")]
        public IHttpActionResult InsertaUsuario(requestUsuario model)
        {
            return Ok(new csUsuario().InsertarUsuario(model.dpi, model.nombre,
                model.correo_electronico, model.fecha_nacimiento, model.telefono, model.direccion, model.contraseña, model.id_rol));
        }

        [HttpPost]
        [Route("api/rest/actualizarUsuario")]
        public IHttpActionResult ActualizarUsuario(requestUsuario model)
        {
            return Ok(new csUsuario().ActualizarUsuario(model.dpi, model.nombre,
                model.correo_electronico, model.fecha_nacimiento, model.telefono, model.direccion, model.contraseña, model.id_rol));
        }

        [HttpPost]
        [Route("api/rest/eliminarUsuarioo")]
        public IHttpActionResult EliminarUsuario(requestUsuario model)
        {
            return Ok(new csUsuario().EliminarUsuario(model.dpi));
        }

        [HttpGet]
        [Route("api/rest/listarUsuario")]
        public IHttpActionResult ListarUsuario()
        {
            return Ok(new csUsuario().ListarUsuario());
        }
        [HttpGet]
        [Route("api/rest/listarUsuario")]
        public IHttpActionResult ListarUsuarioxid(int dpi)
        {
            return Ok(new csUsuario().ListarUsuarioxid(dpi));
        }
    }
}