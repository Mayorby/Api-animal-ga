﻿using ApiVeterinaria.Models.Reservacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using static ApiVeterinaria.Models.Reservacion.csReservacionEstructura;

namespace ApiVeterinaria.Controllers
{
    public class ReservacionController : ApiController
    {
        [HttpPost]
        [Route("api/rest/insertarReservacion")]
public IHttpActionResult InsertarReservacion(requestReservacion model)
        {
            return Ok(new csReservacion().InsertarReservacion(model.id_reserva, model.fecha,
                model.dpi, model.id_mascota, model.estado, model.hora));
        }

        [HttpPost]
        [Route("api/rest/actualizarReservacion")]
        public IHttpActionResult ActualizarReservacion(requestReservacion model)
        {
            return Ok(new csReservacion().ActualizarReservacion(model.id_reserva, model.fecha,
                model.dpi, model.id_mascota, model.estado, model.hora));
        }

        [HttpPost]
        [Route("api/rest/eliminarReservacion")]
        public IHttpActionResult EliminarReservacion(requestReservacion model)
        {
            return Ok(new csReservacion().EliminarReservacion(model.id_reserva));
        }

        [HttpGet]
        [Route("api/rest/listarReservacion")]
        public IHttpActionResult ListarReservacion()
        {
            return Ok(new csReservacion().ListarReservacion());
        }
        [HttpGet]
        [Route("api/rest/listarReservacion")]
        public IHttpActionResult ListarReservacionxid(int id_reserva)
        {
            return Ok(new csReservacion().ListarReservacionxid(id_reserva));
        }
    }
}