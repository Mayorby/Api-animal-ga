﻿using ApiVeterinaria.Models.Producto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using static ApiVeterinaria.Models.Producto.csProductoEstructura;

namespace ApiVeterinaria.Controllers
{
    public class ProductoController : ApiController 
    {
        [HttpPost]
        [Route("api/rest/insertarProducto")]
        public IHttpActionResult InsertarProducto(requestProducto model)
        {
            return Ok(new csProducto().InsertarProducto(model.id_producto, model.nombre_p,
                model.descripcion, model.precio, model.imagen));
        }

        [HttpPost]
        [Route("api/rest/actualizarProducto")]
        public IHttpActionResult ActualizarProducto(requestProducto model)
        {
            return Ok(new csProducto().ActualizarProducto(model.id_producto, model.nombre_p,
                model.descripcion, model.precio, model.imagen));
        }

        [HttpPost]
        [Route("api/rest/eliminarProducto")]
        public IHttpActionResult EliminarProducto(requestProducto model)
        {
            return Ok(new csProducto().EliminarProducto(model.id_producto));
        }

        [HttpGet]
        [Route("api/rest/listarProducto")]
        public IHttpActionResult ListarProducto()
        {
            return Ok(new csProducto().ListarProducto());
        }
        [HttpGet]
        [Route("api/rest/listarProducto")]
        public IHttpActionResult ListarProductoxid(int id_producto)
        {
            return Ok(new csProducto().ListarProductoxid(id_producto));
        }
    }
}