﻿using ApiVeterinaria.Models.Roles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using static ApiVeterinaria.Models.Roles.csRolesEstructura;

namespace ApiVeterinaria.Controllers
{
    public class RolesController : ApiController
    {
        [HttpPost]
        [Route("api/rest/insertaroles")]
        public IHttpActionResult InsertarRoles(requestRoles model)
        {
            return Ok(new csRoles().InsertarRoles(model.id_rol, model.nombre_rol));
        }

        [HttpPost]
        [Route("api/rest/actualizarRoles")]
        public IHttpActionResult ActualizarProducto(requestRoles model)
        {
            return Ok(new csRoles().ActualizarRoles(model.id_rol, model.nombre_rol));
        }

        [HttpPost]
        [Route("api/rest/eliminarRoles")]
        public IHttpActionResult EliminarRoles(requestRoles model)
        {
            return Ok(new csRoles().EliminarRoles(model.id_rol));
        }

        [HttpGet]
        [Route("api/rest/listarRoles")]
        public IHttpActionResult ListarRoles()
        {
            return Ok(new csRoles().ListarRoles());
        }
        [HttpGet]
        [Route("api/rest/listarRoles")]
        public IHttpActionResult ListarRolesxid(int id_rol)
        {
            return Ok(new csRoles().ListarRolesxid(id_rol));
        }
    }
}