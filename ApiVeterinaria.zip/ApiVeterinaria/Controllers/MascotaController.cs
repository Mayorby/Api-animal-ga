﻿using ApiVeterinaria.Models.Mascota;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using static ApiVeterinaria.Models.Mascota.csMascotaEstructura;

namespace ApiVeterinaria.Controllers
{
    public class MascotaController : ApiController
    {
        [HttpPost]
        [Route("api/rest/insertarMascota")]
        public IHttpActionResult InsertarMascota(requestMascota model)
        {
            return Ok(new csMascota().InsertarMascota(model.id_mascota, model.nombre_m,
                model.raza, model.fecha_nacimiento, model.sexo, model.color, model.especie, model.dpi));
        }

        [HttpPost]
        [Route("api/rest/actualizarMascota")]
        public IHttpActionResult ActualizarMascota(requestMascota model)
        {
            return Ok(new csMascota().ActualizarMascota(model.id_mascota, model.nombre_m,
                model.raza, model.fecha_nacimiento, model.sexo, model.color, model.especie, model.dpi));
        }

        [HttpPost]
        [Route("api/rest/eliminarMascota")]
        public IHttpActionResult EliminarMascotao(requestMascota model)
        {
            return Ok(new csMascota().EliminarMascota(model.id_mascota));
        }

        [HttpGet]
        [Route("api/rest/listarMascota")]
        public IHttpActionResult ListarMascota()
        {
            return Ok(new csMascota().ListarMascota());
        }
        [HttpGet]
        [Route("api/rest/listarMascota")]
        public IHttpActionResult ListarMascotaxid(int id_mascota)
        {
            return Ok(new csMascota().ListarMascotaxid(id_mascota));
        }
    }
}